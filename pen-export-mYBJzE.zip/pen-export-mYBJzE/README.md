# YouTube Video Player in Three.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/orvilleChomer/pen/mYBJzE](https://codepen.io/orvilleChomer/pen/mYBJzE).

How to embed a YouTube video into a 3D world using Three.js.
It is based on a sample on the Three.js web site.

In this case, I changed the videos to some of my own, and made it so they start playing automatically and muted.